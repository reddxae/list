{
    until [[ "$(getprop sys.boot_completed)" == "1" ]]; do
        sleep 15
    done

    resetprop -n gsm.sim.operator.iso-country BY
    resetprop -n gsm.operator.iso-country BY
    resetprop -n ro.csc.country_code Belarus
    resetprop -n ro.csc.countryiso_code BY
}&

